# AL-MURATTAL

This is the Next.js starter template for AL-MURATTAL.