export default function Schools() {
  return <h1>Schools Page</h1>;
}