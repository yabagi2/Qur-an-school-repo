export default function Events() {
  return <h1>Events Page</h1>;
}