export default function Admin() {
  return <h1>Admin Page</h1>;
}