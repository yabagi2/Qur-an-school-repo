export default function ProfileCard() {
  return <div>Profile Card Component</div>;
}