export default function ZakatCalculator() {
  return <div>Zakat Calculator Component</div>;
}