export default function EventCalendar() {
  return <div>Event Calendar Component</div>;
}