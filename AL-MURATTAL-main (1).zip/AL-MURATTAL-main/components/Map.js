export default function Map() {
  return <div>Map Component</div>;
}