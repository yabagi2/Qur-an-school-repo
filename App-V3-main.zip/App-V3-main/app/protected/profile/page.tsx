import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default async function ProfilePage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Profile</h1>
            <p className="text-slate-600 dark:text-slate-400">Manage your profile information</p>
          </div>
          <Button asChild variant="outline">
            <Link href="/protected">Back to Dashboard</Link>
          </Button>
        </div>

        <div className="max-w-2xl">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>Update your personal information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <p className="text-slate-600 dark:text-slate-400">{data.user.email}</p>
                <p className="text-xs text-slate-500 mt-1">Email changes require verification</p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Account Status</label>
                <p className="text-slate-600 dark:text-slate-400">
                  {data.user.email_confirmed_at ? "Verified" : "Pending verification"}
                </p>
              </div>

              <div className="pt-4">
                <p className="text-sm text-slate-500">
                  Profile management features can be extended here with forms to update user information, upload
                  avatars, and manage account preferences.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
