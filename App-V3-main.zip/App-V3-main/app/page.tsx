import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default async function HomePage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-slate-100 mb-4 text-balance">
            Welcome to Your App
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto text-pretty">
            A modern, secure application built with Next.js and Supabase authentication.
          </p>
        </div>

        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center">{user ? `Welcome back!` : "Get Started"}</CardTitle>
              <CardDescription className="text-center">
                {user ? `You're signed in as ${user.email}` : "Sign in to access your account"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {user ? (
                <div className="space-y-3">
                  <Button asChild className="w-full">
                    <Link href="/protected">Go to Dashboard</Link>
                  </Button>
                  <form action="/auth/signout" method="post">
                    <Button type="submit" variant="outline" className="w-full bg-transparent">
                      Sign Out
                    </Button>
                  </form>
                </div>
              ) : (
                <div className="space-y-3">
                  <Button asChild className="w-full">
                    <Link href="/auth/login">Sign In</Link>
                  </Button>
                  <Button asChild variant="outline" className="w-full bg-transparent">
                    <Link href="/auth/sign-up">Create Account</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="mt-16 grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Secure Authentication</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-400">
                Built-in user authentication with email verification and secure session management.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Modern Stack</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-400">
                Powered by Next.js 14, TypeScript, Tailwind CSS, and Supabase for a robust foundation.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ready to Scale</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-400">
                Database integration and row-level security policies ensure your app can grow securely.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
